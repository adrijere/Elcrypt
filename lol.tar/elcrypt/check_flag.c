/*
** check_flag.c for elcrypt in /home/debruy_p/rendu/elcrypt
**
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
**
** Started on  Sat Feb 28 16:26:09 2015 Pierre Debruyne
** Last update Sun Mar  1 21:44:48 2015 Lucas Michalski
*/

#include	<stdio.h>
#include	<stdlib.h>
#include	"my.h"
#include	"elcrypt.h"

static void	check3(t_all *all, char ***av)
{
  if (!my_strcmp(**av, "-1") && all->type == -1)
    all->type = 1;
  else if (!my_strcmp(**av, "-2") && all->type == -1)
    all->type = 2;
  else
    {
      printf("Mauvais flag.\n");
      all->error = 1;
    }
}

static void	check2(t_all *all, char ***av)
{
  if (!my_strcmp(**av, "-o"))
    {
      *av += 1;
      if (**av)
	all->dest = **av;
      else
	{
	  all->error = 1;
	  printf("Il manque le nom du fichier de sortie.\n");
	}
    }
  else if (!my_strcmp(**av, "-k"))
    {
      *av += 1;
      if (**av)
	all->key = **av;
      else
	{
	  all->error = 1;
	  printf("Mauvaise clef.\n");
	}
    }
  else
    check3(all, av);
}

void		check_flag(t_all *all, char **av)
{
  while (*av != NULL)
    {
      if (!my_strcmp(*av, "-d") && all->option == -1)
	all->option = 0;
      else if (!my_strcmp(*av, "-e") && all->option == -1)
	all->option = 1;
      else if (!my_strcmp(*av, "-f"))
	{
	  av += 1;
	  if (*av)
	    all->src = *av;
	  else
	    {
	      all->error = 1;
	      printf("Il manque le nom du ficher d'entree.\n");
	    }
	}
      else
	check2(all, &av);
      if (*av)
	av += 1;
    }
}
