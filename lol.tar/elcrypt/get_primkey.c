/*
** get_primkey.c for elcrypt in /home/debruy_p/rendu/elcrypt
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sat Feb 28 18:11:41 2015 Pierre Debruyne
** Last update Sun Mar  1 01:47:05 2015 Pierre Debruyne
*/

#include	<stdlib.h>
#include	"my.h"
#include	"elcrypt.h"

u_key		*get_primkey(t_all *all)
{
  int		i;
  u_key		*prim_key;
  unsigned char	tmp;
  u_key		key_z;

  if ((prim_key = malloc(sizeof(u_key))) == NULL)
    my_exit(MALLOCERR);
  i = 0;
  key_z.my_long = strtoul(all->key, NULL, 16);
  prim_key->my_long = 0;
  while (i < 8)
    {
      tmp = (key_z.my_char[i] >> 1);
      prim_key->my_long = prim_key->my_long | ((unsigned long)tmp << (7 * i));
      i++;
    }
  return (prim_key);
}
