/*
** open_file.c for rush in /home/michal_l/rendu/elcrypt
**
** Made by Lucas Michalski
** Login   <michal_l@epitech.net>
**
** Started on  Sat Feb 28 16:32:52 2015 Lucas Michalski
** Last update Sat Feb 28 22:36:47 2015 Pierre Debruyne
*/

#include	<stdio.h>
#include	<unistd.h>
#include	<stdlib.h>
#include	<fcntl.h>
#include	"elcrypt.h"

void		open_file(t_all *all)
{
  if ((all->src_fd = open(all->src, O_RDONLY)) == -1)
    {
      printf("Mauvais fichier d'entree.\n");
      all->error = 1;
    }
  if ((all->dest_fd = open(all->dest, O_CREAT | O_RDWR | O_TRUNC, 0644)) == -1)
    {
      printf("Mauvais fichier de sortie.\n");
      all->error = 1;
    }
}
