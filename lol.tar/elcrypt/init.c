/*
** init.c for elcrypt in /home/debruy_p/rendu/elcrypt
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sat Feb 28 16:24:21 2015 Pierre Debruyne
** Last update Sun Mar  1 18:58:14 2015 Pierre Debruyne
*/

#include	<stdio.h>
#include	<unistd.h>
#include	<stdlib.h>
#include	"my.h"
#include	"elcrypt.h"

static int	check_all(t_all *all)
{
  if (all->option == -1 || all->src == NULL || all->dest == NULL)
    {
      printf("Il manque des parametres.\n");
      return (0);
    }
  return (1);
}

void	init(char **av)
{
  t_all	all;

  all.type = -1;
  all.error = 0;
  all.option = -1;
  all.src = NULL;
  all.dest = NULL;
  all.src_fd = -1;
  all.dest_fd = -1;
  check_flag(&all, av + 1);
  if (all.error == 0 && check_all(&all))
    {
      open_file(&all);
      if (all.error == 0)
	{
	  all.prim_key = get_primkey(&all);
	  if (all.option == 0)
	    decrypt(&all);
	  else
	    crypt(&all);
	  close(all.src_fd);
	  close(all.dest_fd);
	  free(all.prim_key);
	}
    }
}
