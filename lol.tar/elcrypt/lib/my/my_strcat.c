/*
** my_strcat.c for libmy in /home/debruy_p/rendu/my_libs/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Wed Jan 14 13:37:29 2015 Pierre Debruyne
** Last update Sat Jan 24 20:02:54 2015 Pierre Debruyne
*/

#include	<stdio.h>
#include	<stdlib.h>
#include	"my.h"

char	*my_strcat(char *str1, char *str2)
{
  char	*cat;
  int	len;
  char	*curs;

  len = my_strlen(str1) + my_strlen(str2) + 1;
  if ((str1 == NULL && str2 == NULL))
    return (NULL);
  if ((cat = malloc(sizeof(char) * len)) == NULL)
    my_exit(MALLOCERR);
  cat[len - 1] = 0;
  curs = cat;
  if (str1)
    while (*str1)
      {
	*curs = *(str1++);
	curs++;
      }
  if (str2)
    while (*str2)
      {
	*curs = *(str2++);
	curs++;
      }
  return (cat);
}

char	*my_strncat(char *str1, char *str2, int i)
{
  char	*cat;
  char	*dup2;

  dup2 = my_strndup(str2, i);
  cat = my_strcat(str1, dup2);
  free(dup2);
  return (cat);
}
