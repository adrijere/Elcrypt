/*
** my_strlen.c for libmy in /home/debruy_p/rendu/my_libs/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Wed Jan 14 13:22:27 2015 Pierre Debruyne
** Last update Wed Jan 14 13:23:17 2015 Pierre Debruyne
*/

int	my_strlen(char *str)
{
  int	i;

  i = 0;
  if (str)
    while (*str)
      {
	str++;
	i++;
      }
  return (i);
}
