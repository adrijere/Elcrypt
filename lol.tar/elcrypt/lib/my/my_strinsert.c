/*
** my_strinsert.c for libmy in /home/debruy_p/rendu/my_libs/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Thu Jan 15 14:24:28 2015 Pierre Debruyne
** Last update Thu Jan 15 14:31:30 2015 Pierre Debruyne
*/

#include	<stdlib.h>
#include	"my.h"

char	*my_strinsert(char *str1, char *curs, char *str2)
{
  char	*res;
  char	*res2;

  res = my_strndup(str1, curs - str1);
  res2 = my_strcat(res, str2);
  free(res);
  res = my_strcat(res2, curs);
  free(res2);
  return (res);
}
