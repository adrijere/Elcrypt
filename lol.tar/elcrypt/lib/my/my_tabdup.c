/*
** my_tabdup.c for libmy in /home/debruy_p/rendu/System_unix/PSU_2014_minishell1/lib/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sun Jan 25 17:01:18 2015 Pierre Debruyne
** Last update Sun Jan 25 19:32:17 2015 Pierre Debruyne
*/

#include	<stdlib.h>
#include	"my.h"

char	**my_tabdup(char **tab)
{
  int	size;
  char	**dup;
  char	**curs;

  size = my_tablen(tab);
  if ((dup = malloc(sizeof(char*) * (size + 1))) == NULL)
    my_exit(MALLOCERR);
  dup[size] = 0;
  curs = dup;
  if (tab)
    while (*tab)
      {
	*curs = my_strdup(*tab);
	curs += 1;
	tab += 1;
      }
  return (dup);
}

char	**my_tabndup(char **tab, int i)
{
  char	**dup;
  char	**curs;

  if ((dup = malloc(sizeof(char*) * (i + 1))) == NULL)
    my_exit(MALLOCERR);
  dup[i] = NULL;
  curs = dup;
  if (tab)
    while (*tab && i > 0)
      {
	*curs = my_strdup(*tab);
	curs += 1;
	tab += 1;
	i -= 1;
      }
  return (dup);
}
