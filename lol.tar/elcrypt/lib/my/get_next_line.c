/*
** get_next_line.c for rtv1 in /home/debruy_p/rendu/I_graph/MUL_2014_rtv1
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Tue Feb 24 13:16:30 2015 Pierre Debruyne
** Last update Tue Feb 24 13:21:41 2015 Pierre Debruyne
*/

#include	<unistd.h>
#include	<stdlib.h>
#include	"my.h"

char	*get_next_line(int fd)
{
  char	buff[2];
  char	*mem;
  char	*res;
  int	ret;

  buff[1] = 0;
  res = NULL;
  while ((ret = read(fd, buff, 1)) > 0 && buff[0] != '\n')
    {
      if (ret == -1)
	my_exit("Impossible de lire le fichier.\n");
      mem = my_strcat(res, buff);
      free(res);
      res = mem;
    }
  return (res);
}
