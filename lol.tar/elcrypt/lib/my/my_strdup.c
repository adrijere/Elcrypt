/*
** my_strdup.c for libmy in /home/debruy_p/rendu/my_libs/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Wed Jan 14 13:24:49 2015 Pierre Debruyne
** Last update Sat Jan 24 20:04:04 2015 Pierre Debruyne
*/

#include	<stdlib.h>
#include	"my.h"

char	*my_strdup(char *str)
{
  char	*dup;
  char	*curs;

  if (str == NULL)
    return (NULL);
  if ((dup = malloc(sizeof(char) * (my_strlen(str) + 1))) == NULL)
    my_exit(MALLOCERR);
  curs = dup;
  while (*str)
    {
      *curs = *str;
      str++;
      curs++;
    }
  *curs = 0;
  return (dup);
}

char	*my_strndup(char *str, int i)
{
  char	*dup;

  if (str == NULL)
    return (NULL);
  if ((dup = malloc(sizeof(char) * (i + 1))) == NULL)
    my_exit(MALLOCERR);
  dup[i] = 0;
  i--;
  while (i >= 0)
    {
      dup[i] = str[i];
      i--;
    }
  return (dup);
}
