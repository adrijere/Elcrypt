/*
** my_exit.c for libmy in /home/debruy_p/rendu/System_unix/PSU_2014_minishell1/lib/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sat Jan 24 19:55:56 2015 Pierre Debruyne
** Last update Sat Jan 24 22:17:43 2015 Pierre Debruyne
*/

#include	<stdlib.h>
#include	<unistd.h>
#include	"my.h"

void	my_exit(char *str)
{
  write(2, str, my_strlen(str));
  exit(EXIT_FAILURE);
}
