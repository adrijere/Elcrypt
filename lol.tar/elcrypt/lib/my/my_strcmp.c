/*
** my_strcmp.c for libmy in /home/debruy_p/rendu/my_libs/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Wed Jan 14 14:13:35 2015 Pierre Debruyne
** Last update Tue Jan 20 16:01:15 2015 Pierre Debruyne
*/

#include	<stdlib.h>

int	my_strcmp(char *str1, char *str2)
{
  if (str1 == NULL && str2 == NULL)
    return (0);
  if (str1 == NULL || str2 == NULL)
    return (1);
  while ((*str1 || *str2) && *str1 == *str2)
    {
      str1++;
      str2++;
    }
  return (*str2 - *str1);
}

int	my_strncmp(char *str1, char *str2, int i)
{
  if (str1 == NULL && str2 == NULL)
    return (0);
  if (str1 == NULL || str2 == NULL)
    return (1);
  while ((*str1 || *str2) && *str1 == *str2 && i > 1)
    {
      str1++;
      str2++;
      i--;
    }
  return (*str2 - *str1);
}
