/*
** my_put.c for libmy in /home/debruy_p/rendu/System_unix/test/lib/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Mon Feb  2 23:05:41 2015 Pierre Debruyne
** Last update Mon Feb  2 23:07:52 2015 Pierre Debruyne
*/

#include	<unistd.h>
#include	"my.h"

int	my_put(int fd, char *str)
{
  return (write(fd, str, my_strlen(str)));
}
