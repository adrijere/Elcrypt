/*
** my_str_to_wordtab.c for libmy in /home/debruy_p/rendu/System_unix/PSU_2014_minishell1/lib/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sun Jan 25 16:34:12 2015 Pierre Debruyne
** Last update Sun Jan 25 19:12:16 2015 Pierre Debruyne
*/

#include	<stdlib.h>
#include	"my.h"

static char	**get_tab(char *str, int i)
{
  char		**tab;
  int		j;
  char		*curs;

  if ((tab = malloc(sizeof(char*) * (i + 1))) == NULL)
    my_exit(MALLOCERR);
  tab[i] = NULL;
  j = 0;
  curs = str;
  while (j < i && *curs)
    {
      while (*curs != ' ' && *curs && *curs != '\t')
        curs += 1;
      tab[j] = my_strndup(str, curs - str);
      while (*curs == ' ' || *curs == '\t')
        curs += 1;
      str = curs;
      j += 1;
    }
  return (tab);
}

char	**my_str_to_wordtab(char *str)
{
  int	i;
  char	*curs;

  i = 0;
  while (*str == ' ' || *str == '\t')
    str += 1;
  curs = str;
  while (*curs)
    {
      i += 1;
      while (*curs != ' ' && *curs && *curs != '\t')
        curs += 1;
      while (*curs == ' ' || *curs == '\t')
        curs += 1;
    }
  return (get_tab(str, i));
}
