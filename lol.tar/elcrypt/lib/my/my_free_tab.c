/*
** my_free_tab.c for libmy in /home/debruy_p/rendu/System_unix/PSU_2014_minishell1/lib/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sun Jan 25 16:45:23 2015 Pierre Debruyne
** Last update Sun Jan 25 17:14:12 2015 Pierre Debruyne
*/

#include	<stdlib.h>

void	my_free_tab(char **tab)
{
  char	**curs;

  curs = tab;
  if (curs)
    while (*curs)
      {
	free(*curs);
	curs += 1;
      }
  free(tab);
}
