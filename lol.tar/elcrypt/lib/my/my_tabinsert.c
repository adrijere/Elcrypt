/*
** my_tabinsert.c for libmy in /home/debruy_p/rendu/System_unix/PSU_2014_minishell1/lib/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sun Jan 25 17:18:52 2015 Pierre Debruyne
** Last update Sun Jan 25 17:24:56 2015 Pierre Debruyne
*/

#include	"my.h"

char	**my_tabinsert(char **tab1, char **curs, char **tab2)
{
  char	**res;
  char	**res2;

  res = my_tabndup(tab1, curs - tab1);
  res2 = my_tabcat(res, tab2);
  my_free_tab(res);
  res = my_tabcat(res2, curs);
  my_free_tab(res2);
  return (res);
}
