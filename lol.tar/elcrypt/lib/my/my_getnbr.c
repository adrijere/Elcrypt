/*
** my_getnbr.c for libmy in /home/debruy_p/rendu/my_libs/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Wed Jan 14 13:53:54 2015 Pierre Debruyne
** Last update Tue Feb  3 00:26:30 2015 Pierre Debruyne
*/

#include	<stdlib.h>

static int	my_getnbr2(char *str)
{
  char		*curs;
  char		*curs2;
  int		i;

  while (*str != '-' && (*str < '0' || *str > '9') && *str)
    str++;
  i = 0;
  curs2 = str;
  while (*curs2 == '-' || *curs2 == '+')
    curs2++;
  curs = curs2;
  while (*curs >= '0' && *curs <= '9')
    {
      i *= 10;
      i += *curs - 48;
      curs++;
    }
  while (curs2 >= str)
    if (*(curs2--) == '-')
      i = -i;
  return (i);
}

static int	have_only_zero(char *str)
{
  while (*str)
    {
      if (*str != '0')
	return (0);
      str += 1;
    }
  return (1);
}

int	my_getnbr(char *str)
{
  if (str == NULL)
    return (0);
  if (have_only_zero(str))
    return (0);
  else
    return (my_getnbr2(str));
}
