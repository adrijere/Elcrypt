/*
** my_strinsert.c for libmy in /home/debruy_p/rendu/my_libs/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Thu Jan 15 14:15:39 2015 Pierre Debruyne
** Last update Thu Jan 22 14:39:35 2015 Pierre Debruyne
*/

#include	<stdlib.h>
#include	"my.h"

char	*my_strponct(char *str, char *curs, int i)
{
  char	*res;
  char	*res2;

  res = my_strndup(str, curs - str);
  curs += i;
  res2 = my_strcat(res, curs);
  free(res);
  return (res2);
}
