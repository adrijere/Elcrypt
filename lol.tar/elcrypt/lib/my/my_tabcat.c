/*
** my_tabcat.c for libmy in /home/debruy_p/rendu/System_unix/PSU_2014_minishell1/lib/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sun Jan 25 16:53:02 2015 Pierre Debruyne
** Last update Tue Feb 10 17:30:05 2015 Pierre Debruyne
*/

#include	<stdlib.h>
#include	"my.h"

char	**my_tabcat(char **tab, char **tab2)
{
  int	size;
  char	**cat;
  char	**curs;

  size = my_tablen(tab) + my_tablen(tab2);
  if ((cat = malloc(sizeof(char*) * (size + 1))) == NULL)
    my_exit(MALLOCERR);
  cat[size] = NULL;
  curs = cat;
  if (tab)
    while (*tab)
      {
	*curs = my_strdup(*tab);
	curs += 1;
	tab += 1;
      }
  if (tab2)
    while (*tab2)
      {
	*curs = my_strdup(*tab2);
	curs += 1;
	tab2 += 1;
      }
  return (cat);
}

char	**my_tabncat(char **tab, char **tab2, int i)
{
  int	size;
  char	**cat;
  char	**curs;

  size = my_tablen(tab) + i;
  if ((cat = malloc(sizeof(char*) * (size + 1))) == NULL)
    my_exit(MALLOCERR);
  cat[size] = NULL;
  curs = cat;
  if (tab)
    while (*tab)
      {
	*curs = my_strdup(*tab);
	curs += 1;
	tab += 1;
      }
  if (tab2 && *tab2)
    while (i > 0 && *tab2)
      {
	*curs = my_strdup(*tab2);
	curs += 1;
	tab2 += 1;
	i -= 1;
      }
  return (cat);
}
