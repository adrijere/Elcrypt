/*
** my_tablen.c for libmy in /home/debruy_p/rendu/System_unix/PSU_2014_minishell1/lib/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sun Jan 25 16:50:15 2015 Pierre Debruyne
** Last update Sun Jan 25 16:51:09 2015 Pierre Debruyne
*/

int	my_tablen(char **tab)
{
  int	i;

  i = 0;
  if (tab)
    while (tab[i])
      i += 1;
  return (i);
}
