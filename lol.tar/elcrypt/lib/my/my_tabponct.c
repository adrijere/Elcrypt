/*
** my_tabponct.c for libmy in /home/debruy_p/rendu/System_unix/PSU_2014_minishell1/lib/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sun Jan 25 17:25:26 2015 Pierre Debruyne
** Last update Sun Jan 25 18:48:25 2015 Pierre Debruyne
*/

#include	"my.h"

char	**my_tabponct(char **tab1, char **curs, int i)
{
  char	**res;
  char	**res2;

  res = my_tabndup(tab1, curs - tab1);
  curs += i;
  res2 = my_tabcat(res, curs);
  my_free_tab(res);
  return (res2);
}
