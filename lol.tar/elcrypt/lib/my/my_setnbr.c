/*
** my_setnbr.c for libmy in /home/debruy_p/rendu/my_libs/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Wed Jan 14 14:47:32 2015 Pierre Debruyne
** Last update Tue Feb 17 16:58:03 2015 Pierre Debruyne
*/

#include	<stdlib.h>
#include	"my.h"

static char	*my_setnbr2(int nbr, int mem)
{
  char		*str;
  char		c;
  char		*res;

  str = NULL;
  if (nbr != 0)
    {
      c = (nbr % 10);
      if (c < 0)
	c = -c;
      c += 48;
      str = my_setnbr2(nbr / 10, mem);
      res = my_strncat(str, &c, 1);
      free(str);
      return (res);
    }
  else if (mem < 0)
    str = my_strdup("-");
  else
    str = my_strdup("");
  return (str);
}

char	*my_setnbr(int nbr)
{
  if (nbr == 0)
    return (my_strdup("0"));
  return (my_setnbr2(nbr, nbr));
}
