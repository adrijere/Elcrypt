/*
** crypt.c for elcrypt in /home/debruy_p/rendu/elcrypt
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sat Feb 28 21:36:34 2015 Pierre Debruyne
** Last update Sun Mar  1 21:07:08 2015 Pierre Debruyne
*/

#include	<unistd.h>
#include	"elcrypt.h"

static void	get_bloc(char *buff, u_bloc *bloc)
{
  int		i;

  i = 0;
  while (i < 8)
    {
      bloc->my_char[i] = buff[7 - i];
      i++;
    }
}

static void	go_decrypt(t_all *all, char *buff, int ret)
{
  u_bloc	bloc;
  u_key		sec;
  int		n;
  unsigned int	lr_tmp[2];

  n = 8;
  get_bloc(buff, &bloc);
  lr_tmp[0] = bloc.lr[0];
  bloc.lr[0] = bloc.lr[1];
  bloc.lr[1] = lr_tmp[0];
  while (n > 0)
    {
      rotate_key2(&sec, all->prim_key, n);
      lr_tmp[1] = bloc.lr[1];
      lr_tmp[0] = (sec.my_int[0] ^ bloc.lr[1]) ^ bloc.lr[0];
      bloc.lr[0] = lr_tmp[1];
      bloc.lr[1] = lr_tmp[0];
      n--;
    }
  n--;
  while (++n < 8)
    buff[n] = bloc.my_char[7 - n];
  ret = 0;
  write(all->dest_fd, buff, 8 - ret);
}

void	decrypt(t_all *all)
{
  char	buff[8];
  int	ret;

  while ((ret = read(all->src_fd, buff, 8)) == 8)
    go_decrypt(all, buff, 0);
  if (ret == -1)
    return ;
  if (ret != 0)
    go_decrypt(all, buff, 0);
}
