/*
** main.c for elcrypt in /home/debruy_p/rendu/elcrypt
**
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
**
** Started on  Sat Feb 28 16:16:20 2015 Pierre Debruyne
** Last update Sun Mar  1 21:45:16 2015 Lucas Michalski
*/

#include	<stdio.h>
#include	"elcrypt.h"

int		main(int ac, char **av)
{
  if (ac < 2)
    printf("Usage:./elcrypt -d/-e -f \"fichier\" -o \"fichier\" -k \"clef\"\n");
  else
    init(av);
  return (0);
}
