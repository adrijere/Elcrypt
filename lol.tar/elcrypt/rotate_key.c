/*
** rotate_key.c for elcrypt in /home/debruy_p/rendu/elcrypt
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sat Feb 28 21:32:03 2015 Pierre Debruyne
** Last update Sun Mar  1 20:59:43 2015 Pierre Debruyne
*/

#include	"elcrypt.h"

void		rotate_key1(u_key *sec)
{
  unsigned long	tmp;
  unsigned long	tmp2;

  tmp = (sec->my_long << 4);
  tmp2 = (sec->my_long >> (56 - 4));
  sec->my_long = tmp | tmp2;
  sec->my_char[7] = 0;
}

void		rotate_key2(u_key *sec, u_key *prim, int n)
{
  unsigned long	tmp;
  unsigned long	tmp2;

  sec->my_long = prim->my_long;
  while (n > 1)
    {
      tmp = (sec->my_long << 4);
      tmp2 = (sec->my_long >> (56 - 4));
      sec->my_long = tmp | tmp2;
      sec->my_char[7] = 0;
      n--;
    }
}

void		rotate_key1_2(u_key *sec)
{
  unsigned int	tmp1;
  unsigned int	tmp2;
  unsigned int	tmp3;
  unsigned int	tmp4;

  tmp1 = (sec->my_long >> 4);
  tmp2 = (sec->my_long >> (32 + 4));
  tmp2 <<= 4;
  tmp3 = (tmp1 >> 31);
  tmp3 <<= 4;
  tmp1 <<= 1;
  tmp1 = tmp1 | tmp3;
  tmp4 = (tmp2 >> 31);
  tmp4 <<= 4;
  tmp2 <<= 1;
  tmp2 = tmp2 | tmp4;
  sec->my_long = 0;
  sec->my_long += tmp2;
  sec->my_long <<= (32 - 4);
  sec->my_long += tmp1;
  sec->my_long <<= 4;
}
