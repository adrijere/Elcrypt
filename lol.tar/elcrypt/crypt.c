/*
** crypt.c for elcrypt in /home/debruy_p/rendu/elcrypt
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sat Feb 28 21:36:34 2015 Pierre Debruyne
** Last update Sun Mar  1 18:55:24 2015 Pierre Debruyne
*/

#include	<unistd.h>
#include	"elcrypt.h"

static void	get_bloc(char *buff, u_bloc *bloc)
{
  int		i;

  i = 0;
  while (i < 8)
    {
      bloc->my_char[i] = buff[7 - i];
      i++;
    }
}


static void	go_crypt(t_all *all, char *buff)
{
  u_bloc	bloc;
  u_key		sec;
  int		n;
  unsigned int	lr_tmp[2];

  n = 0;
  get_bloc(buff, &bloc);
  sec.my_long = all->prim_key->my_long;
  lr_tmp[0] = bloc.lr[0];
  bloc.lr[0] = bloc.lr[1];
  bloc.lr[1] = lr_tmp[0];
  while (n < 8)
    {
      lr_tmp[1] = bloc.lr[1];
      lr_tmp[0] = (sec.my_int[0] ^ bloc.lr[1]) ^ bloc.lr[0];
      rotate_key1(&sec);
      bloc.lr[0] = lr_tmp[1];
      bloc.lr[1] = lr_tmp[0];
      n++;
    }
  while (--n >= 0)
    buff[n] = bloc.my_char[7 - n];
  write(all->dest_fd, buff, 8);
}

static void	go_crypt2(t_all *all, char *buff)
{
  u_bloc	bloc;
  u_key		sec;
  int		n;
  unsigned int	lr_tmp[2];

  n = 0;
  get_bloc(buff, &bloc);
  sec.my_long = all->prim_key->my_long;
  lr_tmp[0] = bloc.lr[0];
  bloc.lr[0] = bloc.lr[1];
  bloc.lr[1] = lr_tmp[0];
  while (n < 16)
    {
      lr_tmp[1] = bloc.lr[1];
      lr_tmp[0] = (sec.my_int[0] ^ bloc.lr[1]) ^ bloc.lr[0];
      rotate_key1_2(&sec);
      bloc.lr[0] = lr_tmp[1];
      bloc.lr[1] = lr_tmp[0];
      n++;
    }
  while (--n >= 0)
    buff[n] = bloc.my_char[7 - n];
  write(all->dest_fd, buff, 8);
}

void	crypt(t_all *all)
{
  char	buff[8];
  int	ret;
  int	r;

  while ((ret = read(all->src_fd, buff, 8)) == 8)
    {
      if (all->type == 1)
	go_crypt(all, buff);
      else
	go_crypt2(all, buff);
    }
  if (ret == -1)
    return ;
  r = 8 - ret;
  while (ret < 8)
    {
      buff[ret] = (char)r;
      ret++;
    }
  if (all->type == 1)
    go_crypt(all, buff);
  else
    go_crypt2(all, buff);
}
