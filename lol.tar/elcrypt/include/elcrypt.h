/*
** elcrypt.h for elcrypt in /home/debruy_p/rendu/elcrypt
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Sat Feb 28 16:20:27 2015 Pierre Debruyne
** Last update Sun Mar  1 18:56:01 2015 Pierre Debruyne
*/

#ifndef		ELCRYPT_H_
# define	ELCRYPT_H_

typedef union	u_key
{
  unsigned int	my_int[2];
  unsigned long	my_long;
  unsigned char	my_char[8];
}		u_key;

typedef union	u_bloc
{
  unsigned int	lr[2];
  unsigned char	my_char[8];
}		u_bloc;

typedef struct	s_all
{
  int		type;
  int		option;
  char		*src;
  int		src_fd;
  char		*dest;
  int		dest_fd;
  char		*key;
  int		error;
  u_key		*prim_key;
  u_key		*key_z;
}		t_all;

void	init(char**);
void	check_flag(t_all*, char**);
void	open_file(t_all*);
u_key	*get_primkey(t_all*);
void	rotate_key1(u_key*);
void	rotate_key2(u_key*, u_key*, int);
void	rotate_key1_2(u_key*);

void	crypt(t_all*);
void	decrypt(t_all*);

#endif		/*ELCRYPT_H_*/
