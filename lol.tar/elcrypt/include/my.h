/*
** my.h for libmy in /home/debruy_p/rendu/my_libs/my
** 
** Made by Pierre Debruyne
** Login   <debruy_p@epitech.net>
** 
** Started on  Wed Jan 14 13:23:36 2015 Pierre Debruyne
** Last update Tue Feb 24 13:21:03 2015 Pierre Debruyne
*/

#ifndef		MY_H_
# define	MY_H_

#define		MALLOCERR "Error: Not enouth memory!\n"

int	my_strlen(char*);

char	*my_strdup(char*);
char	*my_strndup(char*, int);

char	*my_strcat(char*, char*);
char	*my_strncat(char*, char*, int);

int	my_strcmp(char*, char*);
int	my_strncmp(char*, char*, int);

char	*my_strinsert(char*, char*, char*);
char	*my_strponct(char*, char*, int);

int	my_getnbr(char*);
char	*my_setnbr(int);

char	**my_str_to_wordtab(char*);

int	my_tablen(char**);

char	**my_tabdup(char**);
char	**my_tabndup(char**, int);

char	**my_tabcat(char**, char**);
char	**my_tabncat(char**, char**, int);

char	**my_tabinsert(char**, char**, char**);
char	**my_tabponct(char**, char**, int);

void	my_free_tab(char**);

void	my_exit(char*);
int	my_put(int, char*);

char	*get_next_line(int);

#endif		/*MY_H_*/
